drink_price=float(input('Enter the price of a drink can (in $):'))
can_count=int(input('Enter number of cans in the pack:'))
pack_cost=drink_price*can_count+1
print(f'Total order cost for the pack of {can_count} cans is ${pack_cost}')

